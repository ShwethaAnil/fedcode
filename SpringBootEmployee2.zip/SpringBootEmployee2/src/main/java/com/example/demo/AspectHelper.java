package com.example.demo;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectHelper {
	
	@Pointcut(value="execution(* com.fed.training.*.*.*(..))")
	public void getPointCut() {
	}
	
	
	@Before("getPointCut()")
	public void beforemethod(JoinPoint joinPoint) {
		System.out.println("Before Each Method"+joinPoint.getSignature().getName());
	}
	
	
	@Before(value="execution(* com.fed.training.bos.*.*())")
	public void beforeonemethod(JoinPoint joinPoint) {
		System.out.println("Before Each Method"+joinPoint.getSignature().getName());
	}
	
	@AfterReturning(value="getPointCut()",returning = "args")
	public void afterretrun(JoinPoint joinPoint,Object args) {
		System.out.println(joinPoint.getSignature());
		System.out.println(args+"  Values");
	}
	
	//web.xml
	
//	<servlet>
//	<servlet-name>
//	<servlet-class>DispactherServlet</servlet-class>
//	
//	
//	
//	@AfterThrowing(value="execution(* com.fed.training.*.*.*(..))",throwing = "ex")
//	public void afterThrows(JoinPoint joinPoint,Throwable ex) {
//		System.out.println(joinPoint.getSignature());
//		System.out.println(ex+"error");
//	}
//	
//	@Around(value="execution(* com.fed.training.*.*.*(..))")
//	public void aroundCode(ProceedingJoinPoint joinPoint) throws Throwable {
//		System.out.println("Around Advice");
//		Object[] args=joinPoint.getArgs();
//		if(args.length>0) {
//			System.out.println("Arguments passed");
//			for(int i=0;i<args.length;i++) {
//				System.out.println("Arguments "+args[i]);
//			}
//		}
//		Object result=joinPoint.proceed(args);
//		System.out.println("Retuning"+result);
//		//return result.toString();
//		
////		System.out.println(joinPoint.getSignature());
////		try {
////			joinPoint.proceed();
////		} catch (Throwable e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////		System.out.println("After proceed");
//	}

}
