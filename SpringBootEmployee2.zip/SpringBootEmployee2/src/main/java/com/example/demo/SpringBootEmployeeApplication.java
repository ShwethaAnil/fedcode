package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;

@SpringBootApplication
@EnableJdbcRepositories("com.example.demo.daos")
@EnableAspectJAutoProxy(proxyTargetClass = true)
//@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
public class SpringBootEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeApplication.class, args);
	}
	
	/*
	 * @Bean public DriverManagerDataSource getDataSource() {
	 * DriverManagerDataSource dataSource=new DriverManagerDataSource();
	 * dataSource.setDriverClassName("oracle.jdbc.OracleDriver");
	 * dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
	 * dataSource.setUsername("system"); dataSource.setPassword("system"); return
	 * dataSource; }
	 */
}
//live load--devtools
//product--system
//catalog--sys2
//main project--product and catalog
//localhost:8081/employees