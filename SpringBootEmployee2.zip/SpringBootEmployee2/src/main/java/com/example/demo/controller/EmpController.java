package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.daos.DepartmentRepo;
import com.example.demo.daos.EmployeeDao;
import com.example.demo.daos.LocationRepo;
import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.model.Location;

@RestController
@RequestMapping("/emp")
public class EmpController {

	@Autowired
	EmployeeDao employeeDao;
	
	@Autowired
	DepartmentRepo departmentRepo;
	
	@Autowired
	LocationRepo locationRepo;
	
	
	@RequestMapping(value="/loc",produces = MediaType.APPLICATION_JSON_VALUE)
	public Iterable<Location> getlocation(){
		Iterable<Location> departments=locationRepo.findlocDep();
		System.out.println("Called");
		System.out.println(departments);
		return departments;
	}
	
	
	@RequestMapping(value="/dep",produces = MediaType.APPLICATION_JSON_VALUE)
	public Iterable<Department> getDepartments(){
		Iterable<Department> departments=departmentRepo.findAll();
		System.out.println("Called");
		System.out.println(departments);
		return departments;
	}
	
	
	@RequestMapping(value="/{name}",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> getEmployeeByName(@PathVariable("name")String name){
		return employeeDao.findByEname(name);
	}
	
	@RequestMapping(value="/{name}/{salary}",produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> getEmployeeByNameAndSalary(@PathVariable("name")String name,
			@PathVariable("salary")double salary){
		return employeeDao.findByEnameAndSalary(name, salary);
	}
	
	
}
