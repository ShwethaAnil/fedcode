package com.example.demo.daos;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.*;

@Repository
public interface EmployeeDao extends CrudRepository<Employee, Integer> {
	
	
	@Query("select * from employee where ename=:name")
	public List<Employee> findByEname(@Param("name") String name);
	
	@Query("select * from employee where ename=:name and salary=:salary")
	public List<Employee> findByEnameAndSalary(@Param("name")String ename,
			@Param("salary")double salary);
	
	@Query("select * from employee where ename=:name or salary=:salary")
	public List<Employee> findByEnameOrSalary(@Param("name")String ename,
			@Param("salary")double salary);

	@Query("select * from employee where ename like 'letter%' ")
	public List<Employee> findByEnameStartsWith(@Param("letter")String letter);
		
}
