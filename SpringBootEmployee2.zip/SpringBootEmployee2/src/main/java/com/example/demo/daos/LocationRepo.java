package com.example.demo.daos;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Location;

@Repository
public interface LocationRepo extends CrudRepository<Location, Integer> {

	@Query("select l.lcode, l.lname,d.deptcode,d.dname from \r\n" + 
			"department  d left outer join location l\r\n" + 
			"on l.lcode=d.lcode")
	public Iterable<Location> findlocDep();
}
