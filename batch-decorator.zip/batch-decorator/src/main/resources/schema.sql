CREATE TABLE customer (
	id number,
	firstName VARCHAR(255) NULL,
	lastName VARCHAR(255) NULL,
	birthdate VARCHAR(255) NULL,
PRIMARY KEY (id)
);