package com.example;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DbWriter implements ItemWriter<UserTab> {
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public void write(List<? extends UserTab> users) throws Exception {
		System.out.println("Data saved to Users "+users);
		userRepository.saveAll(users);	
		System.out.println("Completed");
	}

}
