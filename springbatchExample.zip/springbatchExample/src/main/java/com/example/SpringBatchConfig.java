package com.example;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {
	
	
	
	@Bean
	public Job job(JobBuilderFactory jobBuilderFactory,
			StepBuilderFactory stepBuilderFactory,
			ItemReader<UserTab> itemReader,
			ItemProcessor<UserTab, UserTab> itemProcessor,
			ItemWriter<UserTab> itemWriter) {
		Step step=stepBuilderFactory.get("ETL-file-load")
				.<UserTab,UserTab>chunk(100)
				.reader(itemReader)
				.processor(itemProcessor)
				.writer(itemWriter)
				.build();
		
		
		Job job=jobBuilderFactory.get("ETL-Load")
				.incrementer(new RunIdIncrementer())
				.start(step)
				.build();
		
		return job;	
	}
	
	@Bean
	public FlatFileItemReader<UserTab> itemReader(){
		FlatFileItemReader<UserTab> flatFileItemReader=new FlatFileItemReader<UserTab>();
		flatFileItemReader.setResource(new FileSystemResource("src/main/resources/users.csv"));
		flatFileItemReader.setName("CSV-Reader");
		flatFileItemReader.setLinesToSkip(1);
		flatFileItemReader.setLineMapper(lineMapper());
		return flatFileItemReader;
	}
	//reader--read the data from csv file gdfhds gfhf gdsf
	//jdfgjs hjghjdsf
	//12,Shwteha,56,hgfsadgh--lineTokenizer
	//13,mohan,78,hdsgjhs
	//processor
	//writer--write the data to h2 database
	//User class

	@Bean
	public LineMapper<UserTab> lineMapper() {
		DefaultLineMapper<UserTab> defaultLineMapper=new DefaultLineMapper<UserTab>();
		DelimitedLineTokenizer lineTokenizer=new DelimitedLineTokenizer();
		
		lineTokenizer.setDelimiter(",");
		lineTokenizer.setStrict(false);
		lineTokenizer.setNames(new String[] {"userid","uname","dept","salary"});
		
		BeanWrapperFieldSetMapper<UserTab> fieldSetMapper=new BeanWrapperFieldSetMapper<UserTab>();
		fieldSetMapper.setTargetType(UserTab.class);
		
		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(fieldSetMapper);

		return defaultLineMapper;
	}
	

}
