package com.example;



import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("userTab")
public class UserTab {
	@Id
	private int userid;
	private String uname;
	private String dept;
	private int salary;
	private String dtime;
	
	public UserTab() {
		
	}
	public UserTab(int userid, String uname, String dept, int salary, String dtime) {
		super();
		this.userid = userid;
		this.uname = uname;
		this.dept = dept;
		this.salary = salary;
		this.dtime = dtime;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDtime() {
		return dtime;
	}
	public void setDtime(String dtime) {
		this.dtime = dtime;
	}
	@Override
	public String toString() {
		return "UserTab [userid=" + userid + ", uname=" + uname + ", dept=" + dept + ", salary=" + salary + ", dtime="
				+ dtime + "]";
	}
	
	


	
	
}
