package com.example;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConsumerController {

	@Autowired
	RestTemplate restTemplate;
	
	@RequestMapping(value="/template/emp")
	public String getList() {
		HttpHeaders headers=new HttpHeaders();
		headers.set("x-com-persist","true");
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity=new HttpEntity<String>(headers);
		return restTemplate.exchange("http://localhost:8081/emp/dep", HttpMethod.GET, entity, String.class).getBody();
	
	//http.proxyhost
		//http.proxyport
	}
	//[{"deptcode":1,"dname":"development","lcode":111}]
	
//	@RequestMapping(value="/template/emp/add")
//	public String addDepartment() {
//		HttpHeaders headers=new HttpHeaders();
//		headers.set("x-com-persist","true");
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		
//		Department dept=new Department(12,"Test",123);
//		
//		HttpEntity<Department> entity=new HttpEntity<Department>(dept, headers);
//		
//	return	restTemplate.postForEntity("http://localhost:8081/emp/dep", entity, String.class);
//		
//	}
}
