document.getElementById('btnSave').addEventListener('click',saveTask);

//function
function saveTask(e){
    let title=document.getElementById('title').value;
    let desc=document.getElementById('description').value;
   let x=false;
    let task ={title, desc};

    if(localStorage.getItem('tasks')===null){
        let tasks=[];
        tasks.push(task);
        localStorage.setItem('tasks',JSON.stringify(tasks));
        //alert(localStorage.getItem('tasks'));
    }else{
        let tasks= JSON.parse(localStorage.getItem('tasks'));
        for(let i=0;i<tasks.length;i++){
            if(tasks[i].title === title){
                tasks[i].desc = desc;
                x=true;
            }
            //alert(localStorage.getItem('tasks'));
        }
        if(x === false){
            tasks.push(task);
        }
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }
    //alert(localStorage.getItem('tasks'));
    getTasks();
    document.getElementById('form-task').reset();
    e.preventDefault();
}

function deleteTask(index){
    var  r=window.confirm('Are you sure?');
    if(r===true){
    let tasks= JSON.parse(localStorage.getItem('tasks'));
    tasks.splice(index,1);
    localStorage.setItem('tasks',JSON.stringify(tasks));
    getTasks();
    }
}

function updateTask(title){
    let  formtitle = document.getElementById('title');
    formtitle.value = title;
}

function getTasks(){
    let tasks = JSON.parse(localStorage.getItem('tasks'));
    let taskView = document.getElementById('tasks');
    taskView.innerHTML ='';
    for(let i=0;i<tasks.length;i++){
        let title= tasks[i].title;
        let desc = tasks[i].desc;

        taskView.innerHTML += `<div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-2 text-left">
                <p>${title}</p>
                </div>
                <div class="col-sm-5 text-left">
                <p>${desc}</p>
                </div>  
                <div class="col-sm-2 text-right">
                    <a href="#" onclick="deleteTask('${i}')" class="btn btn-danger ml-5">X</a>
                </div>
                <div class="col-sm-2 text-right">
                    <a href="#" onclick="updateTask('${title}')" class="btn btn-danger ml-5">Edit</a>
                </div>
            </div>
        </div>
     </div>`
    }

    
}